package dev.Frow.Frow.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/testing")
public class LoginController {
   /* @Autowired
    private UserService userService;

    @GetMapping("/{id}")
    public ResponseEntity<Optional<Account>> getSingleMovie(@PathVariable ObjectId id){
        return new ResponseEntity<Optional<Account>>(userService.singleUser(id), HttpStatus.OK);
    }*/


}
