package dev.Frow.Frow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrowApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrowApplication.class, args);
	}



}
