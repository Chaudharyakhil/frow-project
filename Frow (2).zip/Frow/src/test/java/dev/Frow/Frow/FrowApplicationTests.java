package dev.Frow.Frow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrowApplicationTests {

	@Test
	void contextLoads() {
	}

}
